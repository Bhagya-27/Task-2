<?php require_once("login.php");?>
        <div class="container">
            <a href="http://cyan.csam.montclair.edu/~alkhalo1/store.php?product_category=produce">
                <div class="categories">
                    <img src="img/grocery_store.jpg" class="item-image"/>
                    <div class="image-title">Produce</div>
                </div>
            </a>
            <a href="http://cyan.csam.montclair.edu/~alkhalo1/store.php?product_category=frozen_foods">
                <div class="categories">
                    <img src="img/frozen_foods.jpg" class="item-image"/>
                    <div class="image-title">Frozen Foods</div>
                </div>
            </a>
            <a href="http://cyan.csam.montclair.edu/~alkhalo1/store.php?product_category=snacks">
                <div class="categories">
                    <img src="img/snacks.jpg" class="item-image"/>
                    <div class="image-title">Snacks</div>
                </div>
            </a>
            <a href="http://cyan.csam.montclair.edu/~alkhalo1/store.php?product_category=canned_foods">
                <div class="categories">
                    <img src="img/canned_foods.jpg" class="item-image"/>
                    <div class="image-title">Canned Foods</div>
                </div>
            </a>
        </div>
    </body>
</html>